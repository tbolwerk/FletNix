create view MostWatchedMoviesIn2Months (movie_title,publication_year,number_of_times_watched)
as select m.title,m.publication_year,count(wh.movie_id)
from Movie m INNER JOIN WatchHistory wh ON m.movie_id=wh.movie_id
group by m.title,m.publication_year
go

