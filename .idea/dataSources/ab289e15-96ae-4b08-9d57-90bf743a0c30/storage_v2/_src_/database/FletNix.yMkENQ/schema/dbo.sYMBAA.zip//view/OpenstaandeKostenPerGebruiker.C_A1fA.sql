create view OpenstaandeKostenPerGebruiker (Lastname,Firstname,TotalPrice)
as select c.last_name,c.first_name,sum(wh.price)
from Customer c INNER JOIN WatchHistory wh ON c.customer_mail_address=wh.customer_mail_address
where invoiced=1
group by c.last_name,c.first_name
go

