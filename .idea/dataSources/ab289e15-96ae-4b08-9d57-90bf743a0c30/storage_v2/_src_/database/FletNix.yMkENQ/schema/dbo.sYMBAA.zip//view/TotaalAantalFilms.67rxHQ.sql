create view TotaalAantalFilms (totaalFilms) as
(select count(movie_id) from Movie)
go

