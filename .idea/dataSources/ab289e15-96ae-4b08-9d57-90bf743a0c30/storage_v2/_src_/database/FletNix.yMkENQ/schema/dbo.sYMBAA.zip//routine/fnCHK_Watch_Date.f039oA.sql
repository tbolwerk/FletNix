create function dbo.fnCHK_Watch_Date
	(@customer_mail_address varchar(255), @watch_date date)
	returns bit
	as
	begin
	return	case when exists(
								select *
								from Customer
								where customer_mail_address = @customer_mail_address
								AND subscription_start<=@watch_date
								AND subscription_end>=@watch_date
							)
					then 1
					else 0
				END
	END
go

