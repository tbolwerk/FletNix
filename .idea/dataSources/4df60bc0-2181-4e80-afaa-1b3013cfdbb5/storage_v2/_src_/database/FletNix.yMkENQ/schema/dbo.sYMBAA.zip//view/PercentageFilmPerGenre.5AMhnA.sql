create view PercentageFilmPerGenre (genre,percentage) as
(select genre_name,((af.aantal_films*100.0)/(totaalFilms*100.0))*100 from AantalFilmsPerGenre af,TotaalAantalFilms)
go

