create view WatchedMoviesInPast2Months (movie_title,publication_year,number_of_times_watched) as (
select m.title,m.publication_year,count(m.movie_id) from WatchHistory wh INNER JOIN Movie m ON m.movie_id=wh.movie_id
where DATEDIFF(month, CAST(watch_date as date), CURRENT_TIMESTAMP)<=2
group by m.title,m.publication_year 
having count(m.movie_id) >= 1
)
go

