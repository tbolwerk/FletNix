create view INVOICE (lastname,firstname,total_price) as (
select c.last_name,c.first_name,sum(wh.price) 
from WatchHistory wh RIGHT OUTER JOIN Customer c 
ON wh.customer_mail_address=c.customer_mail_address 
where invoiced=0 
group by c.last_name,c.first_name
)
go

