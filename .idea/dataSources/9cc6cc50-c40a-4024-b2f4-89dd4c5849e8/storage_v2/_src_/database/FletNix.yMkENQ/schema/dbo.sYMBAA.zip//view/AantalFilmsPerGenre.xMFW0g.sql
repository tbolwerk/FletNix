create view AantalFilmsPerGenre (genre_name,aantal_films) as
(select mg.genre_name,count(m.movie_id) from Movie_Genre mg LEFT OUTER JOIN Movie m 
ON mg.movie_id=m.movie_id group by mg.genre_name)
go

